"""
Módulo de autenticação e gerenciamento de sessões.
Contém funções para cadastro, login, logout e verificação de permissões.
"""

from typing import Optional
from db import conectar
from security import hash_senha, verificar_senha

# Sessão global - Use uma classe para melhor gestão no futuro
class Sessao:
    usuario_logado: Optional[str] = None
    role_logado: Optional[str] = None

sessao = Sessao()

# Constantes
ROLES_VALIDOS = {"user", "manager"}
SENHA_MINIMA = 6

def cadastrar_usuario(nome: str, senha: str, role: str = "user") -> bool:
    """
    Cadastra um novo usuário no banco de dados.

    Args:
        nome (str): Nome do usuário.
        senha (str): Senha em texto plano.
        role (str): Papel do usuário ('user' ou 'manager').

    Returns:
        bool: True se cadastro foi bem-sucedido, False caso contrário.
    """
    # Validação de entrada
    if not nome or not senha:
        print("Erro: nome e senha não podem ser vazios")
        return False
    
    if len(senha) < SENHA_MINIMA:
        print(f"Erro: senha deve ter pelo menos {SENHA_MINIMA} caracteres")
        return False
    
    if role not in ROLES_VALIDOS:
        print(f"Erro: role deve ser um de {ROLES_VALIDOS}")
        return False
    
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        senha_hash = hash_senha(senha)
        cursor.execute("INSERT INTO usuarios (nome, senha, role) VALUES (?, ?, ?)", (nome, senha_hash, role))
        conexao.commit()
        return True
    except Exception as e:
        print(f"Erro ao cadastrar usuário: {e}")
        return False
    finally:
        conexao.close()

def login_usuario(nome: str, senha: str) -> bool:
    """
    Realiza login de um usuário e inicia sessão.

    Args:
        nome (str): Nome do usuário.
        senha (str): Senha em texto plano.

    Returns:
        bool: True se login foi bem-sucedido, False caso contrário.
    """
    if not nome or not senha:
        print("Erro: nome e senha são obrigatórios")
        return False
    
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute("SELECT senha, role FROM usuarios WHERE nome = ?", (nome,))
        usuario = cursor.fetchone()
        
        if usuario and verificar_senha(senha, usuario[0]):
            sessao.usuario_logado = nome
            sessao.role_logado = usuario[1]
            return True
        
        print("Erro: usuário ou senha inválidos")
        return False
    finally:
        conexao.close()

def logout_usuario():
    """Finaliza a sessão atual."""
    sessao.usuario_logado = None
    sessao.role_logado = None

def usuario_esta_logado() -> bool:
    """
    Verifica se um usuário está atualmente logado.

    Returns:
        bool: True se há usuário logado, False caso contrário.
    """
    return sessao.usuario_logado is not None

def verificar_permissao(role_requerido: str) -> bool:
    """
    Verifica se o usuário logado possui a permissão necessária.
    Implementa hierarquia: 'manager' pode fazer tudo que 'user' faz.

    Args:
        role_requerido (str): Papel necessário ('user' ou 'manager').

    Returns:
        bool: True se o usuário possui permissão, False caso contrário.
    """
    # Valida se está logado
    if not usuario_esta_logado():
        return False
    
    # Hierarquia: manager >= user
    if sessao.role_logado == "manager":
        return True
    
    return sessao.role_logado == role_requerido


def obter_usuario_logado() -> Optional[str]:
    """
    Retorna o nome do usuário atualmente logado.

    Returns:
        Optional[str]: Nome do usuário ou None se não logado.
    """
    return sessao.usuario_logado


def obter_role_logado() -> Optional[str]:
    """
    Retorna o role do usuário atualmente logado.

    Returns:
        Optional[str]: Role do usuário ('user' ou 'manager') ou None se não logado.
    """
    return sessao.role_logado 