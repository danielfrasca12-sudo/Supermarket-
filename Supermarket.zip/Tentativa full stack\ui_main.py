"""
Módulo de interface principal da aplicação de supermercado.

Responsável por:
- Criar a janela principal com a lista de mercado
- Permitir adicionar, remover e atualizar itens
- Exibir botões condicionais (apenas gerente vê logins e calculadora)
- Integrar com ui_manager.py para funções extras
"""

import customtkinter as ctk
from tkinter import messagebox, Listbox
from db import listar_itens, adicionar_item, remover_item, atualizar_item, registrar_login
from auth import obter_usuario_logado, obter_role_logado
from ui_manager import mostrar_logins, abrir_calculadora


# --- Constantes de interface ---
WINDOW_WIDTH = 700
WINDOW_HEIGHT = 550
ENTRY_WIDTH = 200

COLOR_DARK_BG = "#4B4B4B"
COLOR_SUCCESS = "#28a745"
COLOR_SUCCESS_HOVER = "#218838"
COLOR_DANGER = "#dc3545"
COLOR_DANGER_HOVER = "#640101"
COLOR_INFO = "#208ff7"
COLOR_INFO_HOVER = "#1103ce"
COLOR_PURPLE = "#6f42c1"
COLOR_PURPLE_HOVER = "#4a2d91"
COLOR_ORANGE = "#df3f00"


def abrir_lista_mercado():
    """
    Cria e exibe a janela principal de gerenciamento da lista de supermercado.
    """
    global entrada, entrada_preco, lista

    # Registra login
    usuario = obter_usuario_logado()
    registrar_login(usuario)

    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    janela = ctk.CTk()
    janela.title("Lista de Supermercado")
    janela.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")

    titulo = ctk.CTkLabel(janela, text=f"🛒 Lista de Supermercado - Usuário: {usuario}", font=("Arial", 18, "bold"))
    titulo.pack(pady=15)

    # --- Frame para entrada de dados ---
    frame_entrada = ctk.CTkFrame(janela, corner_radius=10)
    frame_entrada.pack(pady=10, padx=10, fill="x")

    lbl_item = ctk.CTkLabel(frame_entrada, text="Item:", text_color="white")
    lbl_item.grid(row=0, column=0, padx=5, pady=5)
    
    entrada = ctk.CTkEntry(frame_entrada, width=ENTRY_WIDTH, placeholder_text="Digite um item...")
    entrada.grid(row=0, column=1, padx=5, pady=5)

    lbl_preco = ctk.CTkLabel(frame_entrada, text="Preço (R$):", text_color="white")
    lbl_preco.grid(row=0, column=2, padx=5, pady=5)
    
    entrada_preco = ctk.CTkEntry(frame_entrada, width=100, placeholder_text="0.00")
    entrada_preco.grid(row=0, column=3, padx=5, pady=5)

    frame_botoes = ctk.CTkFrame(janela, corner_radius=10)
    frame_botoes.pack(pady=10)

    # --- Botões principais ---
    btn_add = ctk.CTkButton(
        frame_botoes,
        text="Adicionar",
        command=adicionar_item_ui,
        width=100,
        fg_color=COLOR_SUCCESS,
        hover_color=COLOR_SUCCESS_HOVER
    )
    btn_add.grid(row=0, column=0, padx=10)

    btn_remover = ctk.CTkButton(
        frame_botoes,
        text="Remover",
        command=remover_item_ui,
        width=100,
        fg_color=COLOR_DANGER,
        hover_color=COLOR_DANGER_HOVER
    )
    btn_remover.grid(row=0, column=1, padx=10)

    btn_atualizar = ctk.CTkButton(
        frame_botoes,
        text="Atualizar",
        command=atualizar_item_ui,
        width=100,
        fg_color=COLOR_INFO,
        hover_color=COLOR_INFO_HOVER
    )
    btn_atualizar.grid(row=0, column=2, padx=10)

    # --- Botões exclusivos para gerente ---
    role = obter_role_logado()
    if role == "manager":
        btn_logins = ctk.CTkButton(
            frame_botoes,
            text="Histórico de Logins",
            command=mostrar_logins,
            width=150,
            fg_color=COLOR_PURPLE,
            hover_color=COLOR_PURPLE_HOVER
        )
        btn_logins.grid(row=1, column=0, columnspan=3, pady=10)

        btn_calc = ctk.CTkButton(
            frame_botoes,
            text="Calculadora",
            command=abrir_calculadora,
            width=150,
            fg_color=COLOR_ORANGE,
            hover_color="#a83200"
        )
        btn_calc.grid(row=2, column=0, columnspan=3, pady=10)

    # --- Lista de itens ---
    lista = Listbox(
        janela,
        width=70,
        height=15,
        bg=COLOR_DARK_BG,
        fg="white",
        font=("Consolas", 11),
        selectbackground=COLOR_ORANGE,
        selectforeground="white",
        highlightthickness=0,
        relief="flat"
    )
    lista.pack(pady=15)

    atualizar_lista_ui()
    janela.mainloop()


# --- Funções auxiliares de interface ---

def atualizar_lista_ui():
    """
    Atualiza a lista exibida na interface com os dados do banco.
    """
    lista.delete(0, ctk.END)
    dados = listar_itens()
    for id_item, nome, preco in dados:
        lista.insert(ctk.END, f"{id_item:02d} - {nome} - R${preco:.2f}")


def adicionar_item_ui():
    """
    Adiciona um item via interface com nome e preço.
    """
    item = entrada.get().strip()
    preco_str = entrada_preco.get().strip()
    
    if not item:
        messagebox.showwarning("Aviso", "Digite um item válido!")
        return
    
    # Validar preço
    try:
        preco = float(preco_str) if preco_str else 0.0
        if preco < 0:
            messagebox.showwarning("Aviso", "O preço não pode ser negativo!")
            return
    except ValueError:
        messagebox.showwarning("Aviso", "Digite um preço válido (ex: 5.50)")
        return
    
    adicionar_item(item, preco)
    entrada.delete(0, ctk.END)
    entrada_preco.delete(0, ctk.END)
    atualizar_lista_ui()
    messagebox.showinfo("Sucesso", f"'{item}' foi adicionado ao banco por R${preco:.2f}.")


def remover_item_ui():
    """
    Remove item selecionado via interface.
    """
    try:
        selecionado = lista.curselection()[0]
        id_item = int(lista.get(selecionado).split(" - ")[0])
        remover_item(id_item)
        atualizar_lista_ui()
        messagebox.showinfo("Removido", f"Item {id_item} foi removido.")
    except IndexError:
        messagebox.showwarning("Aviso", "Selecione um item para remover.")


def atualizar_item_ui():
    """
    Atualiza item selecionado via interface (nome e preço).
    """
    try:
        selecionado = lista.curselection()[0]
        partes = lista.get(selecionado).split(" - ")
        id_item = int(partes[0])
        
        novo_nome = entrada.get().strip()
        preco_str = entrada_preco.get().strip()
        
        if not novo_nome:
            messagebox.showwarning("Aviso", "Digite um novo nome válido!")
            return
        
        # Validar preço
        try:
            novo_preco = float(preco_str) if preco_str else 0.0
            if novo_preco < 0:
                messagebox.showwarning("Aviso", "O preço não pode ser negativo!")
                return
        except ValueError:
            messagebox.showwarning("Aviso", "Digite um preço válido (ex: 5.50)")
            return
        
        atualizar_item(id_item, novo_nome, novo_preco)
        entrada.delete(0, ctk.END)
        entrada_preco.delete(0, ctk.END)
        atualizar_lista_ui()
        messagebox.showinfo("Atualizado", f"Item {id_item} foi atualizado para '{novo_nome}' - R${novo_preco:.2f}.")
    except IndexError:
        messagebox.showwarning("Aviso", "Selecione um item para atualizar.")
