"""
Módulo de segurança para o sistema de supermercado full stack.

Responsável por:
- Geração de hash seguro para senhas
- Verificação de senhas contra hashes armazenados
- Geração de tokens simples de sessão (para reforçar autenticação)
"""

import hashlib
import secrets
import string
from typing import Optional


def hash_senha(senha: str) -> str:
    """
    Gera o hash SHA-256 da senha fornecida.

    Args:
        senha (str): A senha em texto plano.

    Returns:
        str: String hexadecimal com o hash SHA-256.
    """
    return hashlib.sha256(senha.encode()).hexdigest()


def verificar_senha(senha: str, senha_hash: str) -> bool:
    """
    Verifica se a senha corresponde ao hash armazenado.

    Args:
        senha (str): A senha em texto plano a verificar.
        senha_hash (str): O hash armazenado para comparação.

    Returns:
        bool: True se a senha corresponde, False caso contrário.
    """
    return hashlib.sha256(senha.encode()).hexdigest() == senha_hash


def gerar_token_sessao(tamanho: int = 32) -> str:
    """
    Gera um token aleatório para identificar uma sessão de usuário.

    Args:
        tamanho (int): Comprimento do token. Padrão: 32 caracteres.

    Returns:
        str: Token aleatório seguro.
    """
    alfabeto = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alfabeto) for _ in range(tamanho))


def validar_token(token: str, token_esperado: str) -> bool:
    """
    Valida se um token fornecido corresponde ao esperado.

    Args:
        token (str): Token fornecido.
        token_esperado (str): Token esperado.

    Returns:
        bool: True se os tokens correspondem, False caso contrário.
    """
    return secrets.compare_digest(token, token_esperado)


# --- Exemplo de uso interno ---
if __name__ == "__main__":
    senha = "minha_senha_secreta"
    hash_gerado = hash_senha(senha)
    print("Hash:", hash_gerado)
    print("Verificação correta:", verificar_senha("minha_senha_secreta", hash_gerado))
    print("Verificação incorreta:", verificar_senha("senha_errada", hash_gerado))

    token = gerar_token_sessao()
    print("Token gerado:", token)
    print("Token válido?", validar_token(token, token))
