"""
Script de teste e inicialização do sistema de supermercado.

Pode ser executado para:
- Testar as funções principais
- Criar dados de teste no banco
- Validar que tudo está funcionando
"""

from db import (
    criar_tabelas,
    adicionar_usuario,
    adicionar_item,
    listar_itens,
    listar_usuarios,
    listar_logins
)
from security import hash_senha
from auth import login_usuario, obter_usuario_logado, verificar_permissao


def inicializar_dados_teste():
    """
    Cria dados de teste no banco de dados.
    """
    print("\n" + "=" * 60)
    print("🧪 Inicializando dados de teste...")
    print("=" * 60)
    
    # Criar tabelas
    print("\n✓ Criando tabelas...")
    criar_tabelas()
    
    # Criar usuários de teste
    print("✓ Criando usuários de teste...")
    usuarios_teste = [
        ("admin", hash_senha("admin123"), "manager"),
        ("gerente", hash_senha("gerente123"), "manager"),
        ("usuario1", hash_senha("senha123"), "user"),
        ("usuario2", hash_senha("senha456"), "user"),
    ]
    
    for nome, senha, role in usuarios_teste:
        if adicionar_usuario(nome, senha, role):
            print(f"  └─ {nome} ({role}) ✓")
        else:
            print(f"  └─ {nome} ({role}) ✗ (já existe)")
    
    # Criar itens de teste
    print("\n✓ Adicionando itens à lista...")
    itens_teste = [
        ("Pão", 5.50),
        ("Leite", 3.20),
        ("Ovos", 12.00),
        ("Maçã", 8.75),
        ("Arroz", 4.50),
        ("Feijão", 6.80),
        ("Sal", 2.30),
        ("Açúcar", 7.90),
    ]
    
    for item, preco in itens_teste:
        adicionar_item(item, preco)
        print(f"  └─ {item} (R${preco:.2f}) ✓")


def testar_autenticacao():
    """
    Testa as funções de autenticação.
    """
    print("\n" + "=" * 60)
    print("🔐 Testando autenticação...")
    print("=" * 60)
    
    # Teste 1: Login com sucesso
    print("\n✓ Teste 1: Login com sucesso")
    if login_usuario("admin", "admin123"):
        usuario = obter_usuario_logado()
        print(f"  └─ Usuário logado: {usuario} ✓")
    else:
        print("  └─ Login falhou ✗")
    
    # Teste 2: Login com senha errada
    print("\n✓ Teste 2: Login com senha errada")
    if not login_usuario("admin", "senhaerrada"):
        print("  └─ Corretamente rejeitado ✓")
    else:
        print("  └─ Deveria ter falhado ✗")


def testar_permissoes():
    """
    Testa o sistema de permissões.
    """
    print("\n" + "=" * 60)
    print("🛡️ Testando permissões...")
    print("=" * 60)
    
    # Login como manager
    print("\n✓ Login como manager...")
    login_usuario("admin", "admin123")
    
    if verificar_permissao("manager"):
        print("  └─ Permissão manager: OK ✓")
    
    if verificar_permissao("user"):
        print("  └─ Permissão user: OK (hierarquia) ✓")
    
    # Login como user
    print("\n✓ Login como user...")
    login_usuario("usuario1", "senha123")
    
    if verificar_permissao("user"):
        print("  └─ Permissão user: OK ✓")
    
    if not verificar_permissao("manager"):
        print("  └─ Permissão manager: Negada (esperado) ✓")


def listar_dados():
    """
    Lista todos os dados do sistema.
    """
    print("\n" + "=" * 60)
    print("📊 Dados do sistema...")
    print("=" * 60)
    
    # Listar usuários
    print("\n👥 Usuários cadastrados:")
    usuarios = listar_usuarios()
    for id, nome, role in usuarios:
        print(f"  {id}. {nome} ({role})")
    
    # Listar itens
    print("\n🛒 Itens cadastrados:")
    itens = listar_itens()
    for id, item, preco in itens:
        print(f"  {id:02d}. {item} - R${preco:.2f}")
    
    # Listar logins (se houver)
    print("\n📝 Histórico de logins:")
    logins = listar_logins()
    if logins:
        for id, usuario, data in logins:
            print(f"  {id}. {usuario} - {data}")
    else:
        print("  (Nenhum login registrado)")


def main():
    """
    Executa todos os testes.
    """
    print("\n" + "=" * 60)
    print("🧪 TESTE DO SISTEMA DE SUPERMERCADO")
    print("=" * 60)
    
    try:
        # Inicializar dados
        inicializar_dados_teste()
        
        # Testar autenticação
        testar_autenticacao()
        
        # Testar permissões
        testar_permissoes()
        
        # Listar dados
        listar_dados()
        
        print("\n" + "=" * 60)
        print("✅ TODOS OS TESTES PASSARAM COM SUCESSO!")
        print("=" * 60)
        print("\nAgora você pode executar: python main.py")
        print("=" * 60 + "\n")
        
    except Exception as e:
        print(f"\n❌ Erro durante os testes: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
