#!/bin/bash

echo ""
echo "╔═══════════════════════════════════════════════════════════════════════╗"
echo "║                                                                       ║"
echo "║    SISTEMA DE SUPERMERCADO - INSTALADOR AUTOMÁTICO                    ║"
echo "║       (Mac/Linux)                                                     ║"
echo "║                                                                       ║"
echo "╚═══════════════════════════════════════════════════════════════════════╝"
echo ""

# Verificar se Python está instalado
if ! command -v python3 &> /dev/null; then
    echo " ERRO: Python3 não foi encontrado!"
    echo ""
    echo "Solução: Instale Python em https://www.python.org"
    echo ""
    read -p "Pressione Enter para sair..."
    exit 1
fi

echo " Python encontrado!"
echo ""

# Instalar dependências
echo "⏳ Instalando dependências (customtkinter, pillow)..."
echo ""
pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo " ERRO ao instalar dependências!"
    read -p "Pressione Enter para sair..."
    exit 1
fi

echo ""
echo " Dependências instaladas com sucesso!"
echo ""

# Criar dados de teste
echo " Criando banco de dados e dados de teste..."
echo ""
python3 test_setup.py

if [ $? -ne 0 ]; then
    echo ""
    echo "  Aviso: Houve um erro ao criar dados de teste"
    echo "    Mas o programa pode continuar funcionando"
    echo ""
fi

echo ""
echo "╔═══════════════════════════════════════════════════════════════════════╗"
echo "║                                                                       ║"
echo "║   INSTALAÇÃO CONCLUÍDA COM SUCESSO!                                 ║"
echo "║                                                                       ║"
echo "║  Iniciando o programa em 3 segundos...                                ║"
echo "║                                                                       ║"
echo "║  Credenciais de teste:                                                ║"
echo "║    Usuario: admin      Senha: admin123                                ║"
echo "║    Usuario: usuario1   Senha: senha123                                ║"
echo "║                                                                       ║"
echo "╚═══════════════════════════════════════════════════════════════════════╝"
echo ""

sleep 3
python3 main.py

if [ $? -ne 0 ]; then
    echo ""
    echo " ERRO ao iniciar o programa!"
    echo ""
    read -p "Pressione Enter para sair..."
    exit 1
fi
