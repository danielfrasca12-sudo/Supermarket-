"""
Módulo principal do sistema de supermercado full stack.

Responsável por:
- Inicializar o banco de dados
- Abrir a tela de login
- Servir como ponto de entrada da aplicação
- Gerenciar o fluxo principal da aplicação

Estrutura:
- security.py: Geração de hashes e tokens
- db.py: Banco de dados SQLite
- auth.py: Autenticação e permissões
- ui_login.py: Interface de login
- ui_main.py: Interface principal da lista
- ui_manager.py: Funções exclusivas de gerentes
- utils.py: Utilitários e exportação de dados
"""

from db import criar_tabelas
from ui_login import abrir_login


def main():
    """
    Função principal que inicializa o sistema.
    
    Fluxo:
    1. Cria as tabelas do banco de dados (se não existirem)
    2. Abre a tela de login/cadastro
    3. Após login bem-sucedido, abre a tela principal
    """
    print("=" * 50)
    print("🛒 Sistema de Supermercado Full Stack")
    print("=" * 50)
    print("\nInicializando banco de dados...")
    
    # Cria tabelas necessárias
    criar_tabelas()
    
    print("✓ Banco de dados inicializado com sucesso!")
    print("\nAbrindo tela de login...\n")
    
    # Abre tela de login
    abrir_login()
    
    print("\nObrigado por usar o sistema!")
    print("=" * 50)


if __name__ == "__main__":
    main()


