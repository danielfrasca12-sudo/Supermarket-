
print("""
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║       SISTEMA DE SUPERMERCADO FULL STACK - QUICKSTART          ║
║                                                                ║
║  1. pip install -r requirements.txt                            ║
║  2. python test_setup.py                                       ║
║  3. python main.py                                             ║
║                                                                ║
║  Pronto! Sistema funcionando                                   ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
""")
