"""
Módulo de banco de dados para o sistema de supermercado full stack.

Responsável por:
- Conexão com o banco SQLite
- Criação das tabelas necessárias
- Funções CRUD para usuários, lista de mercado e logins
- Utilitários para consultas específicas

Todas as funções retornam dados prontos para uso nas interfaces.
"""

import sqlite3
from typing import List, Tuple, Optional

# Nome do banco de dados
DB_NAME = "supermercado.db"


def conectar() -> sqlite3.Connection:
    """
    Cria e retorna uma conexão com o banco de dados SQLite.

    Returns:
        sqlite3.Connection: Objeto de conexão com o banco.
    """
    return sqlite3.connect(DB_NAME)


def criar_tabelas() -> None:
    """
    Cria todas as tabelas necessárias para o sistema, caso não existam.
    """
    conexao = conectar()
    cursor = conexao.cursor()

    # Tabela de lista de mercado
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS lista (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item TEXT NOT NULL,
        preco REAL DEFAULT 0.0
    )
    """)

    # Tabela de usuários
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT UNIQUE NOT NULL,
        senha TEXT NOT NULL,
        role TEXT DEFAULT 'user'
    )
    """)

    # Tabela de logins
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS logins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT NOT NULL,
        data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conexao.commit()
    conexao.close()


# --- Funções CRUD para lista de mercado ---

def adicionar_item(item: str, preco: float = 0.0) -> None:
    """
    Adiciona um novo item à lista de mercado.

    Args:
        item (str): Nome do item.
        preco (float): Preço do item (opcional).
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("INSERT INTO lista (item, preco) VALUES (?, ?)", (item, preco))
    conexao.commit()
    conexao.close()


def remover_item(id_item: int) -> None:
    """
    Remove um item da lista pelo ID.

    Args:
        id_item (int): ID do item a ser removido.
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("DELETE FROM lista WHERE id = ?", (id_item,))
    conexao.commit()
    conexao.close()


def atualizar_item(id_item: int, novo_nome: str, novo_preco: float) -> None:
    """
    Atualiza nome e preço de um item da lista.

    Args:
        id_item (int): ID do item.
        novo_nome (str): Novo nome do item.
        novo_preco (float): Novo preço do item.
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("UPDATE lista SET item = ?, preco = ? WHERE id = ?", (novo_nome, novo_preco, id_item))
    conexao.commit()
    conexao.close()


def listar_itens() -> List[Tuple[int, str, float]]:
    """
    Retorna todos os itens da lista de mercado.

    Returns:
        List[Tuple[int, str, float]]: Lista de tuplas (id, item, preco).
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("SELECT id, item, preco FROM lista")
    dados = cursor.fetchall()
    conexao.close()
    return dados


# --- Funções CRUD para usuários ---

def adicionar_usuario(nome: str, senha_hash: str, role: str = "user") -> bool:
    """
    Adiciona um novo usuário ao sistema.

    Args:
        nome (str): Nome do usuário.
        senha_hash (str): Hash da senha.
        role (str): Papel do usuário ('user' ou 'manager').

    Returns:
        bool: True se inserção foi bem-sucedida, False caso contrário.
    """
    conexao = conectar()
    cursor = conexao.cursor()
    try:
        cursor.execute("INSERT INTO usuarios (nome, senha, role) VALUES (?, ?, ?)", (nome, senha_hash, role))
        conexao.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conexao.close()


def buscar_usuario(nome: str) -> Optional[Tuple[int, str, str, str]]:
    """
    Busca um usuário pelo nome.

    Args:
        nome (str): Nome do usuário.

    Returns:
        Optional[Tuple[int, str, str, str]]: Tupla (id, nome, senha, role) ou None.
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("SELECT id, nome, senha, role FROM usuarios WHERE nome = ?", (nome,))
    usuario = cursor.fetchone()
    conexao.close()
    return usuario


def listar_usuarios() -> List[Tuple[int, str, str]]:
    """
    Lista todos os usuários cadastrados.

    Returns:
        List[Tuple[int, str, str]]: Lista de tuplas (id, nome, role).
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("SELECT id, nome, role FROM usuarios")
    usuarios = cursor.fetchall()
    conexao.close()
    return usuarios


# --- Funções para logins ---

def registrar_login(usuario: str) -> None:
    """
    Registra um login no histórico.

    Args:
        usuario (str): Nome do usuário que fez login.
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("INSERT INTO logins (usuario) VALUES (?)", (usuario,))
    conexao.commit()
    conexao.close()


def listar_logins() -> List[Tuple[int, str, str]]:
    """
    Lista todos os logins registrados.

    Returns:
        List[Tuple[int, str, str]]: Lista de tuplas (id, usuario, data_hora).
    """
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("SELECT id, usuario, data_hora FROM logins ORDER BY data_hora DESC")
    logins = cursor.fetchall()
    conexao.close()
    return logins
