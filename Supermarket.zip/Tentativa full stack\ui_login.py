"""
Módulo de interface gráfica para login e cadastro de usuários.

Responsável por:
- Criar a janela inicial de login/cadastro
- Capturar nome e senha do usuário
- Chamar funções de autenticação (auth.py)
- Exibir mensagens de sucesso ou erro
"""

import customtkinter as ctk
from tkinter import messagebox
from auth import cadastrar_usuario, login_usuario, obter_usuario_logado, obter_role_logado
from ui_main import abrir_lista_mercado


def abrir_login():
    """
    Cria e exibe a janela de login e cadastro.
    """
    global tela_login, entrada_nome, entrada_senha
    tela_login = ctk.CTk()
    tela_login.title("Login / Cadastro")
    tela_login.geometry("300x250")

    # --- Campo de nome ---
    lbl_nome = ctk.CTkLabel(tela_login, text="Nome:")
    lbl_nome.pack(pady=5)
    entrada_nome = ctk.CTkEntry(tela_login, placeholder_text="Digite seu nome")
    entrada_nome.pack(pady=5)

    # --- Campo de senha ---
    lbl_senha = ctk.CTkLabel(tela_login, text="Senha:")
    lbl_senha.pack(pady=5)
    entrada_senha = ctk.CTkEntry(tela_login, show="*", placeholder_text="Digite sua senha")
    entrada_senha.pack(pady=5)

    # --- Botão de login ---
    btn_login = ctk.CTkButton(tela_login, text="Login", command=login)
    btn_login.pack(pady=10)

    # --- Botão de cadastro ---
    btn_cadastrar = ctk.CTkButton(tela_login, text="Cadastrar", command=cadastrar)
    btn_cadastrar.pack(pady=5)

    tela_login.mainloop()


def login():
    """
    Função chamada ao clicar no botão de login.
    Verifica credenciais e abre a tela principal se sucesso.
    """
    nome = entrada_nome.get().strip()
    senha = entrada_senha.get().strip()

    if login_usuario(nome, senha):
        usuario = obter_usuario_logado()
        role = obter_role_logado()
        messagebox.showinfo("Bem-vindo", f"Olá, {usuario} ({role})!")
        tela_login.destroy()
        abrir_lista_mercado()
    else:
        messagebox.showerror("Erro", "Usuário ou senha incorretos.")


def cadastrar():
    """
    Função chamada ao clicar no botão de cadastro.
    Registra novo usuário no banco e faz login automático.
    """
    nome = entrada_nome.get().strip()
    senha = entrada_senha.get().strip()

    if not nome or not senha:
        messagebox.showwarning("Erro", "Preencha todos os campos.")
        return

    if cadastrar_usuario(nome, senha):
        messagebox.showinfo("Sucesso", f"Usuário '{nome}' cadastrado com sucesso!")
        # Fazer login automático após cadastro bem-sucedido
        if login_usuario(nome, senha):
            usuario = obter_usuario_logado()
            role = obter_role_logado()
            messagebox.showinfo("Bem-vindo", f"Olá, {usuario} ({role})!")
            tela_login.destroy()
            abrir_lista_mercado()
    else:
        messagebox.showerror("Erro", "Usuário já existe ou erro no cadastro.")
