"""
Módulo de interface para funções exclusivas de gerente.

Responsável por:
- Exibir histórico de logins
- Abrir calculadora de compras (somar preços dos itens selecionados)
- Exportar relatórios (CSV)
"""

import customtkinter as ctk
from tkinter import messagebox, Listbox
from db import listar_logins, listar_itens
from utils import exportar_lista_csv


def mostrar_logins():
    """
    Exibe o histórico de logins dos usuários em uma janela de mensagem.
    """
    registros = listar_logins()
    texto = "\n".join([f"{id} - {usuario} ({data})" for id, usuario, data in registros])
    messagebox.showinfo("Histórico de Logins", texto if texto else "Nenhum login registrado.")


def abrir_calculadora():
    """
    Abre uma janela de calculadora de compras.
    Permite selecionar itens e calcular o valor total.
    """
    calc = ctk.CTkToplevel()
    calc.title("Calculadora de Compras")
    calc.geometry("400x350")

    lista_calc = Listbox(calc, width=40, height=10)
    lista_calc.pack(pady=10)

    itens = listar_itens()
    for id, item, preco in itens:
        lista_calc.insert(ctk.END, f"{id} - {item} - R${preco:.2f}")

    def calcular_total():
        selecionados = lista_calc.curselection()
        total = 0
        for i in selecionados:
            partes = lista_calc.get(i).split(" - ")
            preco = float(partes[2].replace("R$", ""))
            total += preco
        messagebox.showinfo("Total", f"Valor total: R${total:.2f}")

    btn_total = ctk.CTkButton(calc, text="Calcular Total", command=calcular_total)
    btn_total.pack(pady=10)


def exportar_relatorio():
    """
    Exporta a lista de mercado para um arquivo CSV.
    """
    arquivo = exportar_lista_csv()
    messagebox.showinfo("Exportação", f"Lista exportada para {arquivo}")
