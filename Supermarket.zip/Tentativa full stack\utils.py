"""
Módulo de utilidades para o sistema de supermercado full stack.

Responsável por:
- Exportar lista de mercado para CSV
- Gerar relatórios simples (ex.: contagem de itens, usuários, logins)
- Funções auxiliares para testes básicos
"""

import csv
from db import conectar, listar_itens, listar_usuarios, listar_logins


def exportar_lista_csv(filename: str = "lista.csv") -> str:
    """
    Exporta a lista de mercado para um arquivo CSV.

    Args:
        filename (str): Nome do arquivo de saída. Padrão: 'lista.csv'.

    Returns:
        str: Caminho/nome do arquivo gerado.
    """
    dados = listar_itens()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Item", "Preço"])
        writer.writerows(dados)
    return filename


def exportar_usuarios_csv(filename: str = "usuarios.csv") -> str:
    """
    Exporta a lista de usuários para um arquivo CSV.

    Args:
        filename (str): Nome do arquivo de saída. Padrão: 'usuarios.csv'.

    Returns:
        str: Caminho/nome do arquivo gerado.
    """
    usuarios = listar_usuarios()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Nome", "Role"])
        writer.writerows(usuarios)
    return filename


def exportar_logins_csv(filename: str = "logins.csv") -> str:
    """
    Exporta o histórico de logins para um arquivo CSV.

    Args:
        filename (str): Nome do arquivo de saída. Padrão: 'logins.csv'.

    Returns:
        str: Caminho/nome do arquivo gerado.
    """
    logins = listar_logins()
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["ID", "Usuário", "Data/Hora"])
        writer.writerows(logins)
    return filename


def gerar_relatorio_resumido() -> str:
    """
    Gera um relatório resumido com estatísticas básicas.

    Returns:
        str: Texto contendo o relatório.
    """
    itens = listar_itens()
    usuarios = listar_usuarios()
    logins = listar_logins()

    relatorio = []
    relatorio.append("=== Relatório Resumido ===")
    relatorio.append(f"Total de itens cadastrados: {len(itens)}")
    relatorio.append(f"Total de usuários cadastrados: {len(usuarios)}")
    relatorio.append(f"Total de logins registrados: {len(logins)}")
    relatorio.append("==========================")

    return "\n".join(relatorio)


# --- Funções de teste básico ---

def testar_exportacoes():
    """
    Testa exportação de lista, usuários e logins.
    """
    print("Exportando lista...")
    print(exportar_lista_csv())
    print("Exportando usuários...")
    print(exportar_usuarios_csv())
    print("Exportando logins...")
    print(exportar_logins_csv())


def testar_relatorio():
    """
    Testa geração de relatório resumido.
    """
    print(gerar_relatorio_resumido())


if __name__ == "__main__":
    # Executa testes básicos quando rodado diretamente
    testar_exportacoes()
    testar_relatorio()
